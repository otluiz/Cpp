---
title: Read Barcodes
type: docs
weight: 20
url: /cpp/read-barcodes/
---


