---
title: Barcodes of Different Types
type: docs
weight: 30
url: /cpp/barcodes-of-different-types/
---


