---
title: Aspose.BarCode for Cpp 18.12 Release Notes
type: docs
weight: 10
url: /cpp/aspose-barcode-for-cpp-18-12-release-notes/
---

{{% alert color="primary" %}} 

This page contains release notes information for Aspose.BarCode for C++ 18.12.

{{% /alert %}} 
## **All Changes**

|**Key**|**Summary**|**Category**|
| :- | :- | :- |
|BARCODENET-37024|Not able to read dotted barcodes from TIFF images|Bug|
## **Public API and Backward Incompatible Changes**
None
