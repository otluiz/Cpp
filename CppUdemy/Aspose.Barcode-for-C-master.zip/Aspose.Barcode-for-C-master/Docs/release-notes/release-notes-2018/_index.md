---
title: Release Notes - 2018
type: docs
weight: 20
url: /cpp/release-notes-2018/
---


